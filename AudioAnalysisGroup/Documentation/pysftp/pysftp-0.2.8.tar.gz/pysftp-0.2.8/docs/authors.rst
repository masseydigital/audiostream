Authors
========

Contributors of code, tests and documentation to the project who have agreed
to have their work enjoined into the project and project license (BSD).

 * Jeff Hinrichs <dundeemt@gmail.com>, http://inre.dundeemt.com/
 * Don Reilly <dreilly1982@gmail.com>, http://github.com/dreilly1982



Acknowledgment
---------------
 * pysftp is a fork, with permission, of ssh.py, originally authored by
   Zeth @ http://zeth.net/archive/2008/05/29/sftp-python-really-simple-ssh/

 * paramiko - http://paramiko-docs.readthedocs.org/

 * Justin Reiners - for support of the project by the donation of a SFTP server
   for testing